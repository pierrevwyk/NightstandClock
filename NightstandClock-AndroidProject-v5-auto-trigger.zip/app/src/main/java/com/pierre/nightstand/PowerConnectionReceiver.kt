package com.pierre.nightstand

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** Opens the clock when external power is connected. */
class PowerConnectionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_POWER_CONNECTED) return

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        }

        // Android permits background activity launches for apps granted
        // SYSTEM_ALERT_WINDOW. This is useful here because the phone is being used as a
        // dedicated charging/nightstand device and the power-connected broadcast itself
        // is delivered even when our process is not running.
        if (Settings.canDrawOverlays(context)) {
            try {
                context.startActivity(launchIntent)
            } catch (_: SecurityException) {
                // OEM-specific background-launch protection can still deny the launch.
            }
        }
    }
}
