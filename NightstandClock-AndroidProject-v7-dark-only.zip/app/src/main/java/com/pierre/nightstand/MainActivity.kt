package com.pierre.nightstand

import android.os.Bundle
import android.os.BatteryManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.app.AlertDialog
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat

/** The actual nightstand clock screen. */
class MainActivity : ComponentActivity() {
    private val powerDisconnectedReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == Intent.ACTION_POWER_DISCONNECTED) {
                finishAndRemoveTask()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the app was opened manually while the phone is not charging,
        // do not leave the nightstand clock running.
        val batteryManager = getSystemService(BatteryManager::class.java)
        if (batteryManager != null && !batteryManager.isCharging) {
            finishAndRemoveTask()
            return
        }

        ContextCompat.registerReceiver(
            this,
            powerDisconnectedReceiver,
            android.content.IntentFilter(Intent.ACTION_POWER_DISCONNECTED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        // Keep the clock visible while the phone is being used as a bedside clock.
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        )

        hideSystemUi()
        setContentView(ClockView(this))

        // One-time setup: Android only allows a background app to bring an Activity to the
        // foreground in this scenario when the user has granted SYSTEM_ALERT_WINDOW.
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Enable automatic charging start")
                .setMessage("To make the clock open automatically when you plug in the charger, allow Nightstand Clock to display over other apps. This is an Android security requirement for background launches.")
                .setPositiveButton("Open setting") { _, _ ->
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Not now", null)
                .show()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(powerDisconnectedReceiver)
        } catch (_: IllegalArgumentException) {
            // Receiver was not registered (for example after an early finish).
        }
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    private fun hideSystemUi() {
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }
}
