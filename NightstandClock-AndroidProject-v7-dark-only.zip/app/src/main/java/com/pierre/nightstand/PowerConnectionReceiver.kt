package com.pierre.nightstand

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.provider.Settings
import android.os.Handler
import android.os.Looper

/** Opens the clock on external power only when the room is dark. */
class PowerConnectionReceiver : BroadcastReceiver() {
    companion object {
        // Lux threshold for nightstand use. Adjust if needed after testing.
        private const val DARK_THRESHOLD_LUX = 10f
        private const val SENSOR_TIMEOUT_MS = 700L
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_POWER_CONNECTED) return

        // Do not auto-start for USB connections. This prevents plugging into a PC for
        // ADB/debugging from launching the nightstand clock.
        val plugged = intent.getIntExtra("plugged", -1)
        if (plugged == 2) return // BatteryManager.BATTERY_PLUGGED_USB

        if (!Settings.canDrawOverlays(context)) return

        val pending = goAsync()
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val lightSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LIGHT)

        // If the phone has no ambient-light sensor, don't guess. Automatic night activation
        // is intentionally disabled rather than starting during daylight.
        if (sensorManager == null || lightSensor == null) {
            pending.finish()
            return
        }

        val handler = Handler(Looper.getMainLooper())
        var finished = false

        fun finish() {
            if (!finished) {
                finished = true
                pending.finish()
            }
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                sensorManager.unregisterListener(this)
                handler.removeCallbacksAndMessages(null)

                if (event.values.isNotEmpty() && event.values[0] <= DARK_THRESHOLD_LUX) {
                    val launchIntent = Intent(context, MainActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
                    }
                    try {
                        context.startActivity(launchIntent)
                    } catch (_: SecurityException) {
                        // OEM-specific background-launch protection may still deny the launch.
                    }
                }
                finish()
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        if (!sensorManager.registerListener(listener, lightSensor, SensorManager.SENSOR_DELAY_NORMAL)) {
            finish()
            return
        }

        // Avoid leaving the receiver waiting indefinitely if the sensor does not report.
        handler.postDelayed({
            sensorManager.unregisterListener(listener)
            finish()
        }, SENSOR_TIMEOUT_MS)
    }
}
