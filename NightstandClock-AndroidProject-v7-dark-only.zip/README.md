# Nightstand Clock

The clock automatically opens when external power is connected **only when the ambient light sensor reports a dark room (10 lux or less)**. USB connections are ignored so connecting the phone to a computer for ADB/debugging does not start the clock.

Removing power closes the clock.

The app uses the phone's ambient light sensor rather than Android screen-saver/daydream features, so it is suitable for phones such as the Honor X7c that do not provide a screen saver option.
