# Nightstand Clock

A minimalist Android bedside clock:
- black OLED-friendly background
- very faint red digits
- landscape-only activity
- screen kept awake while the activity is visible
- tap toggles seconds

## Build
Open in Android Studio and build the debug APK.

`./gradlew assembleDebug`

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Important Android behavior
Modern Android versions restrict applications from unexpectedly launching an Activity from the background. The power receiver therefore does not forcibly pop the clock onto the screen. A future version can use a user-approved notification/PendingIntent flow or device-specific automation.
