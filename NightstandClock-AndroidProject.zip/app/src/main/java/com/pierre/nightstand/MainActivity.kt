package com.pierre.nightstand

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        setContent {
            NightstandClock()
        }
    }
}

@Composable
private fun NightstandClock() {
    var now by remember { mutableStateOf(LocalTime.now()) }
    var showSeconds by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalTime.now()
            delay(500)
        }
    }

    val formatter = if (showSeconds)
        DateTimeFormatter.ofPattern("HH:mm:ss", Locale.getDefault())
    else
        DateTimeFormatter.ofPattern("HH:mm", Locale.getDefault())

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { showSeconds = !showSeconds }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = now.format(formatter),
            color = Color(0xFF5A0808),
            fontSize = 96.sp,
            fontWeight = FontWeight.Light,
            letterSpacing = 2.sp
        )
    }
}
