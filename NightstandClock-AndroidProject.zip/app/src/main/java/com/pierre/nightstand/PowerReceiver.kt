package com.pierre.nightstand

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class PowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Android intentionally restricts background activity launches.
        // We receive power events so future versions can use a notification,
        // exact user-approved intent, or other permitted activation mechanism.
        // The user can always launch the clock normally.
    }
}
