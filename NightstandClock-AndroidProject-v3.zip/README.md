# Nightstand Clock

A minimalist, sleep-friendly bedside clock with a faint red display.

## Automatic charging mode

Android restricts ordinary apps from unexpectedly opening a full-screen activity from the background. This project therefore uses Android's supported **Screen saver (DreamService)** mechanism for reliable automatic activation while charging.

After installing the app, open Android **Settings → Display → Screen saver** (the exact menu name can vary by phone), select **Nightstand Clock**, and set the screen saver to run **while charging**. The clock is deliberately dim and fullscreen.

The clock is larger in this version and uses a black background with faint red digits.
