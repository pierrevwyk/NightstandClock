package com.pierre.nightstand

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Opens the clock when external power is connected. */
class PowerConnectionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_POWER_CONNECTED) return

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            addFlags(Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        }

        // ACTION_POWER_CONNECTED wakes a manifest receiver even when the app is not running.
        // If the phone/OEM allows an activity launch from this system event, this brings the
        // clock straight to the foreground. On newer Android versions background-launch rules
        // may still block it; the clock itself remains fully usable when opened manually.
        try {
            context.startActivity(launchIntent)
        } catch (_: SecurityException) {
            // Some Android/OEM versions block background activity launches. Do not crash the
            // receiver; Android will keep the app installed and the user can launch it normally.
        }
    }
}
