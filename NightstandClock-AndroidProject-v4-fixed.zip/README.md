# Nightstand Clock

A minimalist, sleep-friendly bedside clock with a faint red display.

## Clock screen

Opening the app now goes directly to the fullscreen clock. The clock keeps the display awake and uses a larger display size for bedside viewing.

## Automatic charging mode

The app listens for Android's `ACTION_POWER_CONNECTED` system broadcast and attempts to bring the clock activity to the foreground when external power is connected.

Android and some phone manufacturers restrict apps from launching an activity from the background. The older Screen saver/DreamService approach is intentionally not required, because some phones (including the Honor X7c setup this app is intended for) do not expose Android's Screen saver feature.
